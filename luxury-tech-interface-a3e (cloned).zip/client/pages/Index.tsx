import { motion } from "framer-motion";

export default function Index() {
  // Array com todas as seções em ordem de posicionamento
  const sections = [
    {
      src: "https://api.builder.io/api/v1/image/assets/TEMP/49e3fbe4d3ee2f74c79fca6a65919cfcd9b3c50c?width=3840",
      alt: "S1_CAPA_DOLTFACE",
      height: 972,
      hasVideo: false,
    },
    {
      src: "https://api.builder.io/api/v1/image/assets/TEMP/0f8fd0648ba01aa1f995207bdfcd4d6a81c58034?width=3840",
      alt: "S2_IMPACTO-CENTRAL-ESSENCIA",
      height: 972,
      hasVideo: true,
      videoUrl: "https://pikaso.cdnpk.net/private/production/3163540196/video.mp4?token=exp=1770076800~hmac=ecb1fc1d7f34e9c2bf9dc28f14f485a5aa516469fa44d11e5703491a5a2c39d6",
    },
    {
      src: "https://api.builder.io/api/v1/image/assets/TEMP/83769cfc28974c1c3340958fad30399205df100a?width=3840",
      alt: "S3_MANIFESTO-DE-ABERTURA",
      height: 1398,
      hasVideo: false,
    },
    {
      src: "https://api.builder.io/api/v1/image/assets/TEMP/f0156db65dfef1efb5ca56fad797c7896d2ed820?width=3840",
      alt: "S4_INSIGHT-ESTRATEGICO-2",
      height: 353,
      hasVideo: false,
    },
    {
      src: "https://api.builder.io/api/v1/image/assets/TEMP/e2d044dc8686a59933730418e4d614012d9c1856?width=3840",
      alt: "S6_ITINERARIO-COMPLETO",
      height: 2016,
      hasVideo: false,
    },
    {
      src: "https://api.builder.io/api/v1/image/assets/TEMP/03975e7068b8a78db20fa691cc6e2471c2ce5aa5?width=3840",
      alt: "S11_PATROCINADOR",
      height: 2724,
      hasVideo: false,
    },
    {
      src: "https://api.builder.io/api/v1/image/assets/TEMP/06fe4ed75292704d038dad900ed79ef5cf8f448a?width=3840",
      alt: "S7_EXPERIENCIA-E-CURADORIA-LOCAL",
      height: 1492,
      hasVideo: false,
    },
    {
      src: "https://api.builder.io/api/v1/image/assets/TEMP/238023287a8bdf6057b96032ddc1b7a328531f37?width=3840",
      alt: "S12_PITCH-VENDAS",
      height: 310,
      hasVideo: false,
    },
    {
      src: "https://api.builder.io/api/v1/image/assets/TEMP/3fbbf4bd00a08c26e53c2cb8f294375e8669d038?width=3840",
      alt: "S8_IDENTIDADE-E-DIRECAO-CRIATIVA",
      height: 1725,
      hasVideo: false,
    },
    {
      src: "https://api.builder.io/api/v1/image/assets/TEMP/be7459f8abd66349aec9163b5e95c2d8a85c7b5d?width=3840",
      alt: "ARQUITETURAEMOCKUPS",
      height: 2313,
      hasVideo: false,
    },
    {
      src: "https://api.builder.io/api/v1/image/assets/TEMP/aa2d465812dfaffd1bc5c3ed4ac8f9a808565a90?width=3840",
      alt: "S9_DIFERENCIAL-ESTRATEGICO-APLICADO",
      height: 972,
      hasVideo: false,
    },
    {
      src: "https://api.builder.io/api/v1/image/assets/TEMP/fb8d2913b6fc28460f7f96825cf36f37144b868e?width=3840",
      alt: "S10_INSIGHT-ESTRATEGICO-3",
      height: 360,
      hasVideo: false,
    },
    {
      src: "https://api.builder.io/api/v1/image/assets/TEMP/96941a10cc849feb8f1528df896937f90c69b0a0?width=3840",
      alt: "S12_IDEALIZADORES",
      height: 1354,
      hasVideo: false,
    },
  ];

  return (
    <div className="w-full bg-black">
      {sections.map((section, index) => {
        // Proporção da imagem: altura / largura = height / 1920
        const aspectRatio = section.height / 1920;
        
        return (
          <motion.section
            key={index}
            className="w-full relative overflow-hidden flex items-center justify-center group"
            style={{
              aspectRatio: `1920 / ${section.height}`,
            }}
            initial={{ opacity: 0 }}
            whileInView={{ opacity: 1 }}
            transition={{ duration: 0.8, ease: "easeOut" }}
            viewport={{ once: false, amount: 0.3 }}
          >
            {/* Seção com vídeo background */}
            {section.hasVideo ? (
              <>
                {/* Vídeo background */}
                <motion.video
                  autoPlay
                  muted
                  loop
                  playsInline
                  className="absolute inset-0 w-full h-full object-cover"
                  initial={{ scale: 1 }}
                  whileInView={{ scale: 1.05 }}
                  transition={{ duration: 10, ease: "easeInOut" }}
                  viewport={{ once: false, amount: 0.5 }}
                >
                  <source src={section.videoUrl} type="video/mp4" />
                  <img src={section.src} alt={section.alt} className="w-full h-full object-cover" />
                </motion.video>

                {/* Overlay gradiente dinâmico */}
                <motion.div
                  className="absolute inset-0 bg-gradient-to-b from-transparent via-black/10 to-black/40"
                  animate={{
                    opacity: [0.3, 0.5, 0.3],
                  }}
                  transition={{
                    duration: 6,
                    repeat: Infinity,
                    ease: "easeInOut",
                  }}
                />

                {/* Efeito de brilho sofisticado */}
                <motion.div
                  className="absolute inset-0 bg-gradient-to-r from-transparent via-white/5 to-transparent pointer-events-none"
                  animate={{
                    x: ["-100%", "100%"],
                  }}
                  transition={{
                    duration: 10,
                    repeat: Infinity,
                    ease: "linear",
                  }}
                />
              </>
            ) : (
              /* Imagem estática com animações elegantes */
              <motion.img
                src={section.src}
                alt={section.alt}
                className="w-full h-full object-cover"
                loading={index === 0 ? "eager" : "lazy"}
                initial={{ scale: 1 }}
                whileInView={{ scale: 1.02 }}
                transition={{ duration: 1, ease: "easeOut" }}
                viewport={{ once: false, amount: 0.3 }}
              />
            )}

            {/* Efeito de transição suave entre seções */}
            <motion.div
              className="absolute inset-0 bg-gradient-to-b from-transparent to-black/20 pointer-events-none group-hover:from-transparent group-hover:to-black/40 transition-all duration-700"
              initial={{ opacity: 0 }}
              whileInView={{ opacity: 1 }}
              transition={{ duration: 1.2, ease: "easeOut" }}
              viewport={{ once: false, amount: 0.3 }}
            />
          </motion.section>
        );
      })}
    </div>
  );
}
