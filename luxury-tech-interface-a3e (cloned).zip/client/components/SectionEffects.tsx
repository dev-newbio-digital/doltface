import { motion } from "framer-motion";

export function SectionEffects() {
  return (
    <>
      {/* Linhas flutuantes animadas */}
      <motion.div
        className="absolute top-0 left-0 w-1 h-32 bg-gradient-to-b from-amber-400/50 to-transparent pointer-events-none"
        animate={{
          x: [0, 50, 0],
          opacity: [0.3, 0.8, 0.3],
        }}
        transition={{
          duration: 8,
          repeat: Infinity,
          ease: "easeInOut",
        }}
      />

      {/* Brilho de movimento */}
      <motion.div
        className="absolute -top-1/2 -right-1/4 w-1/3 h-96 rounded-full bg-gradient-radial from-amber-400/20 to-transparent blur-3xl pointer-events-none"
        animate={{
          x: [0, 100, 0],
          y: [0, 50, 0],
        }}
        transition={{
          duration: 10,
          repeat: Infinity,
          ease: "easeInOut",
        }}
      />
    </>
  );
}

// Componente para efeito de partículas
export function ParticleEffect() {
  return (
    <div className="absolute inset-0 overflow-hidden pointer-events-none">
      {[...Array(5)].map((_, i) => (
        <motion.div
          key={i}
          className="absolute w-1 h-1 bg-white/30 rounded-full"
          animate={{
            y: [-100, window.innerHeight + 100],
            x: Math.random() * window.innerWidth,
            opacity: [0, 1, 0],
          }}
          transition={{
            duration: 5 + Math.random() * 5,
            repeat: Infinity,
            delay: i * 0.5,
          }}
        />
      ))}
    </div>
  );
}

// Componente para overlay dinâmico
export function DynamicOverlay() {
  return (
    <motion.div
      className="absolute inset-0 bg-gradient-to-b from-transparent via-black/0 to-black/50 pointer-events-none"
      animate={{
        opacity: [0.3, 0.5, 0.3],
      }}
      transition={{
        duration: 5,
        repeat: Infinity,
        ease: "easeInOut",
      }}
    />
  );
}
