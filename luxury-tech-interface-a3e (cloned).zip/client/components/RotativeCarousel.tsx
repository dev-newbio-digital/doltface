import { motion } from "framer-motion";
import { useEffect, useState } from "react";

interface RotativeCarouselProps {
  items: string[]; // URLs das imagens
  autoplay?: boolean;
  interval?: number; // em ms
  className?: string;
}

export function RotativeCarousel({
  items,
  autoplay = true,
  interval = 5000,
  className = "",
}: RotativeCarouselProps) {
  const [activeIndex, setActiveIndex] = useState(0);

  useEffect(() => {
    if (!autoplay) return;

    const timer = setInterval(() => {
      setActiveIndex((prev) => (prev + 1) % items.length);
    }, interval);

    return () => clearInterval(timer);
  }, [items.length, interval, autoplay]);

  return (
    <div className={`relative w-full h-full overflow-hidden group ${className}`}>
      {/* Imagens do carousel com efeito de transição sofisticado */}
      {items.map((item, index) => (
        <motion.div
          key={index}
          className="absolute inset-0"
          initial={{ opacity: 0, scale: 0.95 }}
          animate={{
            opacity: activeIndex === index ? 1 : 0,
            scale: activeIndex === index ? 1 : 0.95,
          }}
          transition={{ duration: 1.8, ease: "easeInOut" }}
        >
          <img
            src={item}
            alt={`Carousel item ${index}`}
            className="w-full h-full object-cover"
          />
        </motion.div>
      ))}

      {/* Overlay gradiente sofisticado com efeito de brilho */}
      <motion.div
        className="absolute inset-0 bg-gradient-to-b from-transparent via-transparent to-black/40 pointer-events-none"
        animate={{
          opacity: [0.4, 0.6, 0.4],
        }}
        transition={{
          duration: 4,
          repeat: Infinity,
          ease: "easeInOut",
        }}
      />

      {/* Borda animada sofisticada */}
      <motion.div
        className="absolute inset-0 border border-white/20 pointer-events-none rounded-lg"
        animate={{
          borderColor: [
            "rgba(255, 255, 255, 0.2)",
            "rgba(212, 175, 55, 0.4)",
            "rgba(255, 255, 255, 0.2)",
          ],
        }}
        transition={{
          duration: 3,
          repeat: Infinity,
          ease: "easeInOut",
        }}
      />

      {/* Indicadores de navegação com efeito sofisticado */}
      <div className="absolute bottom-6 left-1/2 -translate-x-1/2 flex gap-2 z-10">
        {items.map((_, index) => (
          <motion.button
            key={index}
            className={`h-1 rounded-full transition-all cursor-pointer ${
              activeIndex === index ? "bg-amber-400 w-8 shadow-lg" : "bg-white/30 w-2"
            }`}
            onClick={() => setActiveIndex(index)}
            whileHover={{ scale: 1.3, backgroundColor: "rgba(212, 175, 55, 0.8)" }}
            whileTap={{ scale: 0.9 }}
            animate={activeIndex === index ? {
              boxShadow: [
                "0 0 10px rgba(212, 175, 55, 0.5)",
                "0 0 20px rgba(212, 175, 55, 0.8)",
                "0 0 10px rgba(212, 175, 55, 0.5)",
              ],
            } : {}}
            transition={{
              boxShadow: {
                duration: 2,
                repeat: Infinity,
              },
            }}
          />
        ))}
      </div>

      {/* Contador e texto */}
      <motion.div
        className="absolute bottom-6 right-6 text-white/70 text-xs font-light tracking-widest z-10"
        animate={{ opacity: [0.5, 1, 0.5] }}
        transition={{ duration: 3, repeat: Infinity }}
      >
        {String(activeIndex + 1).padStart(2, "0")} / {String(items.length).padStart(2, "0")}
      </motion.div>

      {/* Setas de navegação (opcional) */}
      <motion.button
        className="absolute left-4 top-1/2 -translate-y-1/2 z-20 opacity-0 group-hover:opacity-100 transition-opacity"
        onClick={() => setActiveIndex((prev) => (prev - 1 + items.length) % items.length)}
        whileHover={{ scale: 1.1 }}
        whileTap={{ scale: 0.9 }}
      >
        <div className="w-10 h-10 rounded-full border border-white/30 flex items-center justify-center hover:border-amber-400 hover:text-amber-400 transition-colors">
          ←
        </div>
      </motion.button>

      <motion.button
        className="absolute right-4 top-1/2 -translate-y-1/2 z-20 opacity-0 group-hover:opacity-100 transition-opacity"
        onClick={() => setActiveIndex((prev) => (prev + 1) % items.length)}
        whileHover={{ scale: 1.1 }}
        whileTap={{ scale: 0.9 }}
      >
        <div className="w-10 h-10 rounded-full border border-white/30 flex items-center justify-center hover:border-amber-400 hover:text-amber-400 transition-colors">
          →
        </div>
      </motion.button>
    </div>
  );
}
