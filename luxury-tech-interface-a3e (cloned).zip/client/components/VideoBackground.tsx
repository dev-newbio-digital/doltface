import { motion } from "framer-motion";
import { ReactNode } from "react";

interface VideoBackgroundProps {
  videoSrc: string;
  fallbackImage: string;
  children?: ReactNode;
  className?: string;
}

export function VideoBackground({
  videoSrc,
  fallbackImage,
  children,
  className = "",
}: VideoBackgroundProps) {
  return (
    <div className={`relative w-full h-full overflow-hidden ${className}`}>
      {/* Vídeo background com filtro de escala */}
      <motion.video
        autoPlay
        muted
        loop
        playsInline
        className="absolute inset-0 w-full h-full object-cover"
        animate={{
          scale: [1, 1.02, 1],
        }}
        transition={{
          duration: 10,
          repeat: Infinity,
          ease: "easeInOut",
        }}
      >
        <source src={videoSrc} type="video/mp4" />
        <img src={fallbackImage} alt="Video fallback" className="w-full h-full object-cover" />
      </motion.video>

      {/* Overlay gradiente sofisticado com animação dinâmica */}
      <motion.div
        className="absolute inset-0 bg-gradient-to-b from-transparent via-black/20 to-black/60"
        animate={{
          opacity: [0.5, 0.7, 0.5],
        }}
        transition={{
          duration: 6,
          repeat: Infinity,
          ease: "easeInOut",
        }}
      />

      {/* Efeito de luz/brilho que passa */}
      <motion.div
        className="absolute inset-0 bg-gradient-to-r from-transparent via-white/10 to-transparent"
        animate={{
          x: ["-100%", "100%"],
          opacity: [0, 1, 0],
        }}
        transition={{
          duration: 8,
          repeat: Infinity,
          ease: "easeInOut",
        }}
      />

      {/* Efeito de brilho lateral dourado */}
      <motion.div
        className="absolute -top-1/2 -right-1/4 w-96 h-96 rounded-full bg-gradient-radial from-amber-400/30 to-transparent blur-3xl pointer-events-none"
        animate={{
          scale: [1, 1.3, 1],
          opacity: [0.2, 0.5, 0.2],
        }}
        transition={{
          duration: 8,
          repeat: Infinity,
          ease: "easeInOut",
        }}
      />

      {/* Linhas decorativas animadas */}
      <motion.div
        className="absolute top-0 left-0 w-full h-1 bg-gradient-to-r from-transparent via-amber-400/30 to-transparent"
        animate={{
          x: ["-100%", "100%"],
        }}
        transition={{
          duration: 10,
          repeat: Infinity,
          ease: "linear",
        }}
      />

      {/* Conteúdo */}
      <div className="relative z-10 w-full h-full">{children}</div>
    </div>
  );
}
